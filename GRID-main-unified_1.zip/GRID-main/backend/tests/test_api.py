"""실행: cd backend && python -m pytest -q"""
import os
import sys
import tempfile
from pathlib import Path

os.environ["GRID_DB"] = str(Path(tempfile.mkdtemp()) / "test.db")
os.environ["AI_ENABLED"] = "0"
os.environ["POST_INTERVAL"] = "0"
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient  # noqa: E402

import main  # noqa: E402

client = TestClient(main.app)

SAMPLE = {"x": 10, "z": 20, "lat": 37.34, "lng": 127.92, "zone": "a1", "type": "tree", "text": "여름에 그늘이 없어요"}


def test_health():
    assert client.get("/api/health").json()["status"] == "ok"


def test_create_list_like_stats():
    r = client.post("/api/complaints", json=SAMPLE)
    assert r.status_code == 201
    c = r.json()
    assert c["zone"] == "A1" and c["likes"] == 0

    assert any(x["id"] == c["id"] for x in client.get("/api/complaints").json())
    assert client.get(f"/api/complaints?since_id={c['id']}").json() == []

    assert client.post(f"/api/complaints/{c['id']}/like").json()["likes"] == 1
    assert client.post("/api/complaints/99999/like").status_code == 404

    s = client.get("/api/stats").json()
    assert s["total"] >= 1 and s["by_type"]["tree"] >= 1
    assert s["top_zones"][0]["zone"] == "A1"


def test_validation():
    assert client.post("/api/complaints", json={**SAMPLE, "type": "ufo"}).status_code == 400
    assert client.post("/api/complaints", json={**SAMPLE, "type": "bench"}).status_code == 400  # 예전 유형은 새 등록 불가
    assert client.post("/api/complaints", json={**SAMPLE, "text": ""}).status_code == 422
    assert client.post("/api/complaints", json={**SAMPLE, "text": "가" * 201}).status_code == 422


def test_summary_without_ai():
    d = client.get("/api/ai/summary").json()
    assert d["ai"] is False and "건" in d["summary"]


def test_env_without_key(monkeypatch):
    monkeypatch.delenv("DATA_GO_KR_KEY", raising=False)
    main.envdata._cache.update(at=0, data=None)
    d = client.get("/api/env").json()
    assert d["air"] is None and "key" in d["errors"]


def test_env_with_mocked_apis(monkeypatch):
    monkeypatch.setenv("DATA_GO_KR_KEY", "x")
    main.envdata._cache.update(at=0, data=None)
    air = {"response": {"body": {"items": [
        {"stationName": "춘천", "pm10Value": "10"},
        {"stationName": "반곡동(명륜동)", "dataTime": "2026-11-09 01:00", "pm10Value": "32", "pm25Value": "18",
         "o3Value": "0.021", "no2Value": "0.012", "khaiValue": "55", "khaiGrade": "2", "pm25Grade1h": "2"}]}}}
    kma = {"response": {"body": {"items": {"item": [
        {"category": "T1H", "obsrValue": "6.3"}, {"category": "REH", "obsrValue": "71"}, {"category": "WSD", "obsrValue": "1.2"}]}}}}

    def fake(url, params, timeout=8):
        return air if "Arpltn" in url else kma

    monkeypatch.setattr(main.envdata, "_get_json", fake)
    d = client.get("/api/env").json()
    assert d["air"]["station"] == "반곡동(명륜동)" and d["air"]["pm25"] == 18 and d["air"]["grade"] == "보통"
    assert d["weather"]["temp"] == 6.3 and d["weather"]["humidity"] == 71
    assert len(client.get("/api/env/history").json()) >= 1


def test_kma_grid():
    # 기상청 격자: 원주 무실동 부근은 nx 76, ny 122 근처
    nx, ny = main.envdata.latlng_to_grid(37.3355, 127.925)
    assert 74 <= nx <= 78 and 120 <= ny <= 124


def test_priority():
    client.post("/api/complaints", json={**SAMPLE, "x": 300, "z": 300, "type": "tree"})
    client.post("/api/complaints", json={**SAMPLE, "x": 302, "z": 301, "type": "shade"})
    z = client.get("/api/priority?limit=5").json()
    assert len(z) >= 1 and z[0]["rank"] == 1 and "score" in z[0] and "name" in z[0]
    hit = [r for r in client.get("/api/priority?limit=300").json() if r["proposals"] >= 2]
    assert hit and hit[0]["heat_after"] <= hit[0]["heat"]
    p = client.get("/api/ai/policy").json()
    assert p["ai"] is False and "1위" in p["text"]


def test_priority_uses_zone_mean_and_no_arbitrary_ties():
    # 시민 요구가 같으면(요구 0인 구역끼리) 열섬 '구역 평균'이 높은 곳이 위에 있어야 한다.
    # (예전: 상위 10% 지수가 100에서 포화 → 평균 49 구역이 3위로 올라가던 문제)
    rows = main.heatmodel.priority([])
    assert all(rows[i]["heat"] >= rows[i + 1]["heat"] for i in range(len(rows) - 1))
    for r in rows[:5]:
        assert 0 <= r["paved"] <= 1 and 0 <= r["green"] <= 1


def test_duplicate_same_cell_same_type_blocked():
    body = {**SAMPLE, "x": 123, "z": 45, "type": "shade"}
    assert client.post("/api/complaints", json=body).status_code == 201
    assert client.post("/api/complaints", json=body).status_code == 409
    # 다른 유형이나 다른 칸은 그대로 등록됨
    assert client.post("/api/complaints", json={**body, "type": "tree"}).status_code == 201
    assert client.post("/api/complaints", json={**body, "x": 124}).status_code == 201


def test_meta():
    m = client.get("/api/meta").json()
    assert m["zone_size"] > 0 and m["width"] > 0 and m["depth"] > 0
